SLOVENCINA FINAL
1) OrcaSlicer: skopiruj sk do C:/Program Files/OrcaSlicer/resources/i18n/ -> Slovak
2) Flash Studio 1.7.13: skopiruj Orca-Flashforge.mo do .../i18n/de/ -> Deutsch
3) Flash Studio 1.7.18 ma preklady v exe, .mo necita.